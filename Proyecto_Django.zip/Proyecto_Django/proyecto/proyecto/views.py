from django.http import HttpResponse
from django.views import View
from django.shortcuts import render, redirect
import json


def index(request):
    
    return HttpResponse("Hola Mundo")

class Inicio(View):
    template_name = "index.html"

    def post(self,request):
        return render(request)
    
    def get(self,request):
        
         
        nombre = "Daniel"
        apellido = "Villa"
        Apellido1  = "Corona"
        edad   = 33
        Fecha_Nacimiento= "01/06/1990"
        Mobile_Num="33-11-12-25-52"
        Correo= "daniel.villa@hmail.com"
        Direccion= "Av. De los Parques 3363"

        datos = {
            'nom': "Daniel",
            'apellido' : "Villa",
            'Apellido1'  : "Corona",
            'edad'   : "33",
            'Fecha_Nacimiento': "01/06/1990",
            'Mobile_Num': "33-11-12-25-52",
            'mail' : "daniel.villa@hmail.com",
            'Direccion': "Av. De los Parques 3363",
        }
        
        skills ={
            'trabajo_equipo': 'Trabajo en equipo',
            'Analisis_inf': 'Analisis de informacion',
            'responsable': 'Responsable',
        }

        Job = {
            "lugar_trabajo": "Oracle",
            "anio_inicio": 2015,
            "puesto": 'Analyst'
        }

        cv = {**datos, 
              **skills, 
              **Job}
      

        return render(request,self.template_name,cv)  

